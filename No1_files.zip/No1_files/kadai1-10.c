#include <stdio.h>
#include <stdlib.h>

#define N 3

int main(void)
{
  int *dai;

  dai=(int *)malloc(N*sizeof(int));

  {
    int n;

    dai[1]=123;

    printf("%d\n\n",dai[1]);

    printf("%p\n\n", dai);

    for(n=0;n<sizeof(dai);n++)
      printf("%p %02x\n",(char *)&dai+n,*((char *)&dai+n));
    printf("\n");

    for(n=0;n<sizeof(int [N]);n++)
      printf("%p %02x\n",(char *)dai+n,*((char *)dai+n));
    printf("\n");

  }

  free(dai);

  return 0;
}
