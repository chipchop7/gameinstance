#include <stdio.h>

int main(void)
{
  int i;
  
  i=511;

  printf("Value= %d\n",*(0x    ));

  return 0;
}
