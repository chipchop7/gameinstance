#include <stdio.h>
int main(void)
{
  int ai[3]={0,1,2};
  int n=2;
  
  printf("%d\n",ai[n]);
  printf("%d\n",n[ai]);
  printf("%d\n",(ai+n)[0]);
  printf("%d\n",0[ai+n]);
  
  return 0;
}
