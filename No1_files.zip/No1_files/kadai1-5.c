#include <stdio.h>

#define N 3

int main(void)
{
  int ai[N];

  printf("%ld\n",sizeof(int)*N);
  printf("%ld\n",sizeof(ai));
  printf("%ld\n",sizeof(int [N]));
  
  return 0;
}
