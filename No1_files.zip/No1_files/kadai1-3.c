#include <stdio.h>

int main(void)
{
  int i;
  
  i=511;
  {
    int j;
    for(j=0;j<sizeof(i);j++)
      printf("%p %02x\n",((char *)&i+j),*((char *)&i+j));
  }
  
  return 0;
}
