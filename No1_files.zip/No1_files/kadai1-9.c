#include <stdio.h>
int main(void)
{
  int ai[3]={0,1,2};
  int n;

  for(n=0;n<3;n++)
    printf("%p %02x\n",ai+n,*(ai+n));
  printf("\n");
  
  for(n=0;n<sizeof(ai);n++)
    printf("%p %02x\n",(char *)ai+n,*((char *)ai+n));
  printf("\n");

  return 0;
}
